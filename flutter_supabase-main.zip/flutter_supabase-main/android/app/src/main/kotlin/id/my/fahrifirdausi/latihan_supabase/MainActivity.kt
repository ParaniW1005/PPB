package id.my.fahrifirdausi.latihan_supabase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
